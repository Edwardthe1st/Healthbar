# Handoff: HealthBar — Calorie & Nutrition Tracking App (iOS)

## Overview
HealthBar is a mobile (iOS-style) health app that tracks calories and macros, lets users
search/log foods, create their own dishes, chat with a nutrition coach, review a daily diary
and weekly insights, manage their account/settings, and sign in / create an account.

This handoff documents a single-file interactive prototype (`HealthBar App.dc.html`) that
contains the whole app as a stack of screens switched by an in-memory `screen` state.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the
intended look and behavior. They are **not** production code to copy directly. The task is to
**recreate these designs in your existing codebase** (React Native, SwiftUI, Flutter, web, etc.)
using your established components, navigation, and state patterns. The HTML uses a small custom
templating runtime (`support.js`) — ignore that runtime; only the markup, styles, and behavior
described below matter.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interactions are intentional and
should be reproduced closely, adapted to your platform's idioms (e.g. native navigation, native
keyboard, real date pickers).

## Design System / Tokens

All colors are driven by CSS custom properties on the root of each screen. The chosen direction
is **"Tide"** (cool teal).

| Token            | Value                                              | Use |
|------------------|----------------------------------------------------|-----|
| `--accent`       | `oklch(0.62 0.105 212)` (≈ teal `#2E8C9E`)         | Primary actions, active states, progress fills |
| `--ink`          | `#172223`                                          | Primary text |
| `--muted`        | `#69767a`                                           | Secondary text, icons |
| `--bg`           | `#f1f6f7`                                            | Screen background |
| `--card`         | `#ffffff`                                            | Cards, list rows, bars |
| `--track`        | `color-mix(in oklch, var(--accent) 12%, #e8eef0)`   | Progress-bar tracks |
| Danger (delete/sign-out/error) | `oklch(0.6 0.16 25)` (≈ red `#C8483C`) | Destructive actions |
| Online status dot | `oklch(0.72 0.16 150)` (green)                     | Coach "online" indicator |

Accent tints are produced with `color-mix(in oklch, var(--accent) N%, <base>)` — e.g. soft
button fills use 6–16% accent, borders use ~18–40% accent. Reproduce with your platform's
color-blend or precomputed tints.

### Typography
- Font: system UI stack (`-apple-system, system-ui, sans-serif`).
- Screen titles: 26–30px / weight 700 / letter-spacing −0.02em.
- Section headers (uppercase eyebrows): 11.5–12px / weight 600 / letter-spacing 0.05–0.06em / `--muted`.
- Card titles & list rows: 15–16px / weight 600.
- Big numbers (calories, per-serving): 44–46px / weight 700 / letter-spacing −0.03em.
- Body/secondary: 12.5–14.5px / weight 500.

### Spacing / Shape
- Screen horizontal padding: 16px (cards), 22px (section headers).
- Card radius: 20–28px. Pills/toggles: 999px. Small chips: 13–16px.
- List-row vertical padding: ~12–13px, divider `1px solid rgba(0,0,0,0.05)`.
- Card shadow: `0 1px 2px rgba(0,0,0,0.04), 0 8–10px 20–26px rgba(0,0,0,0.045)`.
- Accent button shadow: `0 6–8px 16–18px color-mix(in oklch, var(--accent) 36–42%, transparent)`.
- Bottom tab bar / action bars: white, top border `1px solid rgba(0,0,0,0.06)`, bottom padding 28px (home-indicator safe area). Status-bar top padding ~54–62px.

## Navigation Model
A single root holds `screen` state. Values:
`home, search, create, coach, diary, insights, account, editprofile, settings,
goalCalories, goalMacros, activity, dietary, connected, reminders, units, auth`.

- **Bottom tab bar** (Home / Diary / center ＋ / Insights / Coach) appears on Home, Diary, Insights.
- The center **＋** opens `search` (Add food).
- Detail/editor screens use a back chevron (top-left) returning to their parent.
- The **AC avatar** (Home header) opens `account`.
- The **gear** (Account header) opens `settings`.
- **Sign out** (Account) → `auth`. Auth success / social → `home`. **Delete profile** confirm → `auth`.

## Screens / Views

### 1. Home (`home`)
- **Header**: "Good morning, Alex" (23px/650) + circular avatar with initials (derived from profile name).
- **Hero card**: "Calories left" + "Goal 2,400"; big number `1,240 kcal`; horizontal progress bar (52% filled, accent on `--track`); footer "1,160 eaten" / "+220 exercise".
- **Macro row**: three equal cards (Protein 84/120g, Carbs 142/240g, Fat 38/70g), each with a thin progress bar (70% / 59% / 54%).
- **Today list card**: rows (striped thumbnail placeholder 46×46 radius 13, title, "meal · Xg protein", kcal). Items: Oatmeal & berries 320 (Breakfast), Grilled chicken salad 480 (Lunch), Greek yogurt 180 (Snack). "Add meal" link → search.
- **Coach teaser**: accent-tinted card "Ask Healthbar" + example question → coach.
- **Tab bar**.

### 2. Add food / Log meal (`search`)
- Grabber + "Add food" title + "Cancel" (→ home).
- **Search field** (rounded, magnifier icon, live text); clear (✕) button when non-empty; barcode button (right).
- **Meal target chips**: Breakfast / Lunch / Dinner / Snack (single active = accent fill; others = white).
- **Results list**: filtered live by query (case-insensitive substring). Each row: thumbnail, name, "serving · Xg protein", kcal, and a circular toggle (＋ outline → check filled when selected).
- **"Create a custom food"** dashed CTA → create.
- **Bottom action bar**: running total `{totalKcal} kcal` + "{n} items selected", and "Add to {meal}" button (enabled only with a selection) → home.
- Sample foods (id, name, serving, kcal, protein): Grilled chicken breast/100g/165/31; Chicken Caesar salad/1 bowl/320/28; Chicken thigh roasted/100g/209/26; Rotisserie chicken/3oz/190/24; Chicken & rice bowl/1 bowl/540/34; Greek yogurt plain/170g/100/17; Oatmeal cooked/1 cup/158/6; Banana/1 medium/105/1; Almonds/28g/164/6; Salmon fillet/100g/208/20. Default query "chicken", default selected = first item, default meal "Lunch".

### 3. Create dish (`create`)
- Back chevron (→ search) + "New dish" title.
- **Photo slot** (dashed, striped, "Add a photo").
- **Dish name** input (default "Bolognese pasta").
- **Servings stepper** (− / value / +, min 1, max 20, default 4).
- **Per-serving nutrition card**: big `{perKcal}` kcal + "{totalKcal} kcal total"; three macro bars (Protein/Carbs/Fat) whose widths are the macro's share of total macro-calories (P×4, C×4, F×9).
- **Ingredients list**: each row = name, "{qty} × {unit} · {kcal} kcal", and a pill stepper (−/qty/+). − at qty 1 removes the row.
- **"Add ingredient"** dashed CTA opens a **bottom-sheet picker** (overlay + sheet, max-height 74%): tappable rows add to the recipe; already-added rows show a qty pill, others a ＋ circle. "Done" closes.
- **Bottom bar**: `{perKcal} kcal` + "Makes N servings" + **Save dish** (enabled when name non-empty AND ≥1 ingredient) → home.
- Ingredient pool (id, name, unit, kcal, P/C/F): pasta/Pasta cooked/200g/220/8·43·1; tomato/Tomato sauce/1 cup/100/4·18·3; beef/Ground beef/100g/250/26·0·17; oil/Olive oil/1 tbsp/119/0·0·14; parm/Parmesan/20g/84/8·1·6; onion/Onion/1 medium/44/1·10·0; garlic/Garlic/2 cloves/9/0·2·0; mozz/Mozzarella/30g/90/7·1·7; chicken/Chicken breast/100g/165/31·0·4; basil/Fresh basil/handful/5/1·1·0. Default recipe: pasta×2, tomato×1, beef×1, parm×1.

### 4. Coach (`coach`)
- Header: back chevron (→ home), coach avatar (bars icon) with green online dot, "Healthbar Coach" / "Nutrition assistant · Online".
- **Context strip** (centered pill): "Today · 1,240 kcal left · 84g protein".
- **Message list**: bot bubbles (white, left, tail bottom-left, with avatar) and user bubbles (accent, right, white text, tail bottom-right). Auto-scrolls to bottom on update.
- **Typing indicator**: three blinking dots (keyframes `hbblink`, 1.2s, staggered .2s/.4s).
- **Suggestion chips** (shown only before first user message): "How much protein do I have left?", "Suggest a 500-cal lunch", "Is oatmeal good post-workout?".
- **Input bar**: text field (Enter sends) + circular send button (enabled when non-empty & not typing).
- **Bot replies** call an LLM (`window.claude.complete` in the prototype) with a system-style prompt that includes today's data; falls back to keyword-based canned answers (protein / lunch / breakfast / snack / oatmeal-workout / water / weight). In your app, wire this to your own assistant endpoint; keep the same prompt context (goal 2,400; 1,160 eaten; 1,240 left; P84/120, C142/240, F38/70; meals logged) and the same fallback strings.

### 5. Diary (`diary`)
- Title "Diary" + calendar icon; date pager (‹ "Today · Jun 18" ›).
- **Summary card**: "Eaten today" 1,160/2,400 kcal + progress bar (48%) + P 84g / C 142g / F 38g.
- **Meal sections** (Breakfast 320 / Lunch 480 / Snack 360 / Dinner 0): each a card with food rows (thumbnail, name, "serving · Xg protein", kcal) and an "Add food" row (→ search). Dinner shows "Nothing logged yet".
- Tab bar (Diary active).

### 6. Insights (`insights`)
- Title "Insights" / "Last 7 days".
- **Calorie chart card**: "Calories" + "avg 2,010 kcal"; 7 vertical bars (heights 114/129/108/139/121/133/67 px) with a dashed **goal line** ("goal 2,400") near the top; last bar (today, "W") uses solid accent, others a muted accent tint; weekday labels T F S S M T **W**.
- **Stat tiles** (3): "2,010 Avg kcal", "96g Avg protein", "7 Day streak" (streak number in accent).
- **Average macros card**: Protein 96/120g (80%), Carbs 198/240g (82%), Fat 64/70g (91%) — label + track + value rows.
- Tab bar (Insights active).

### 7. Account (`account`)
- Back chevron (→ home) + "Account" + **gear** (→ settings).
- **Profile block**: 78px avatar (initials), name (default "Alex Carter"), email ("alex.carter@email.com"), "Edit profile" pill (→ editprofile).
- **Goals group**: Daily calorie goal (→ goalCalories), Macro targets (→ goalMacros), Activity level (→ activity) — each row shows a colored 30px icon tile, label, current value, chevron.
- **Preferences group**: Dietary preferences (→ dietary), Connected apps (→ connected), Reminders (→ reminders), Units (→ units).
- **Sign out** row (red) → auth.
- Each row's trailing value reflects live settings state (see below).

### 8. Edit profile (`editprofile`)
- Top bar: "Cancel" (→ account, discards) / "Edit profile" / **Save** (persists draft → profile, returns to account).
- Avatar (initials) with camera badge + "Change photo".
- **Profile info** grouped inputs: Name, Username (@ prefix), Email, Phone. Helper text about email/phone usage.
- Editing writes to a `draft` copy; Save commits it (name change updates avatar initials everywhere).

### 9. Settings (`settings`)
- Back chevron (→ account) + "Settings".
- **Privacy & security**: Confidentiality ("Only me"), Access & permissions ("Camera, Health").
- **Payment**: Payment methods ("Visa •• 4242"), Bank account (RIB) ("FR76 •• 1234").
- **Danger zone**: **Delete profile** → opens a centered confirmation dialog (overlay, trash icon, "Delete profile?", warning copy, red "Delete profile" → auth, "Cancel" closes).

### 10. Goal · Calories (`goalCalories`)
- Big centered value `{calorieGoal}` kcal/day with − / + circular steppers (±50, clamp 1000–5000; + is accent filled).
- **Quick set** chips: 1800/2000/2200/2400/2600 (active = accent). Helper copy.

### 11. Goal · Macros (`goalMacros`)
- Three rows (Protein/Carbs/Fat) each with a pill stepper (±5g, clamp 0–500).
- Footer row "From macros → {kcal} kcal" computed as P×4 + C×4 + F×9 (live).

### 12. Activity level (`activity`)
- Single-select list: Sedentary / Light / Moderate / Active / Very active, each with a description and a radio (check when selected). Default "Moderate".

### 13. Dietary preferences (`dietary`)
- Multi-select checklist: Vegetarian, Vegan, Pescatarian, Keto, Gluten-free, Dairy-free (square check). Default: Dairy-free on. Account summary shows "None" / single name / "N selected".

### 14. Connected apps (`connected`)
- Toggle (switch) rows: Apple Health (on), Google Fit, Fitbit, Garmin. Switch = 44×26 track, 22px knob, accent when on (`translateX(18px)`). Summary "None" / single / "N connected".

### 15. Reminders (`reminders`)
- Master "Meal reminders" switch. When on, a second group of switches: Breakfast, Lunch, Dinner, Water (Water default off). Summary "On"/"Off".

### 16. Units (`units`)
- Two segmented controls: Measurement (Metric / Imperial) and Energy (kcal / kJ). Selected segment = white pill on tinted track.

### 17. Auth (`auth`) — Sign in / Create account
- **Brand header**: 62px rounded accent tile with the HealthBar "bars" mark; title + subtitle (change by mode).
- **Choose mode**: "Continue with Apple" (black), "Continue with Google" (white, colored G), divider "or", "Continue with email" (accent) → email mode; "New here? Create an account" → signup.
- **Email (sign in) mode**: Email + Password fields, "Forgot password?", primary "Sign in" (enabled when email length > 3 AND password ≥ 6); toggle to signup; "All sign-in options" → choose.
- **Signup mode**: fields Username (@), Email, Password, Date of birth (full-width row), Weight (kg) + Height (cm) side-by-side (label and value centered in each tile), Phone number. Primary "Create account" (enabled when email > 3, password ≥ 6, username length > 1). Toggle to sign in; "All sign-in options".
- Footer: "By continuing you agree to Healthbar's Terms & Privacy Policy."
- Any successful auth / social → home.

## Interactions & Behavior
- All navigation is local state switching (no URLs). Replace with your platform's navigator/stack.
- Text inputs raise the keyboard (prototype toggles a `keyboard` prop on focus/blur; use the native keyboard).
- Live search filtering; live recompute of recipe nutrition and macro→kcal totals; steppers with clamps; single-select radios; multi-select checks; switches.
- Coach: async assistant call with optimistic user bubble + typing indicator, then reply; keyword fallback.
- Switch animation: knob `transform` transition .2s; track `background` .2s. Typing dots: `@keyframes hbblink` (opacity .25→1, translateY −2px), 1.2s infinite, staggered.

## State Management
- `screen` (enum above).
- Profile: `{ name, username, email, phone }` + `draft` copy for editing. Avatar initials derive from name (first letters of first two words).
- Search: `query`, `meal`, `selected` (set of food ids).
- Create: `name`, `servings`, `items` ([{id, qty}]), `showPicker`.
- Coach: `messages` ([{role, text}]), `input`, `typing`.
- Settings: `{ calorieGoal, macros:{protein,carbs,fat}, activity, diet:{...bool}, connected:{...bool}, reminders:{enabled,Breakfast,Lunch,Dinner,Water}, units:{measure,energy} }`.
- Auth: `authMode` (choose|email|signup), `authEmail, authPassword, authUsername, authDob, authWeight, authHeight, authPhone`.
- Delete dialog: `showDelete`.
- Derived per render: filtered results, totals, per-serving macros, percentages, row summaries, validation booleans.

## Data / Backend (to add in real app)
The prototype is front-end only. For production wire up: account auth (Apple/Google/email),
profile + settings persistence, a foods/dishes database with search, daily log storage, and the
coach assistant endpoint. Replace all seed arrays and the `window.claude.complete` call.

## Assets
No external image assets. All icons are inline SVG (home, list, bars/chart, chat, search,
barcode, camera, chevrons, plus/minus, check, trash, send, Apple logo, multicolor Google "G",
HealthBar "bars" mark). Food/photo thumbnails are CSS striped placeholders — swap for real
images. Fonts: system stack (no web fonts).

## Files
- `HealthBar App.dc.html` — the complete, current app (all 17 screens). **Primary reference.**
- `Healthbar Home.dc.html`, `Healthbar Log Meal.dc.html`, `Healthbar Create Dish.dc.html`,
  `Healthbar Coach.dc.html` — earlier standalone single-screen versions (superseded by the app file; included for reference only).
